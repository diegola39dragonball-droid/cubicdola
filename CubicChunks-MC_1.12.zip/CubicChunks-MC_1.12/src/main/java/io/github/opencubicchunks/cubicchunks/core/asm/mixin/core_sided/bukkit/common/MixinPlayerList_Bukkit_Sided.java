/*
 *  This file is part of Cubic Chunks Mod, licensed under the MIT License (MIT).
 *
 *  Copyright (c) 2015-2021 OpenCubicChunks
 *  Copyright (c) 2015-2021 contributors
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *  THE SOFTWARE.
 */
package io.github.opencubicchunks.cubicchunks.core.asm.mixin.core_sided.bukkit.common;

import io.github.opencubicchunks.cubicchunks.api.util.Coords;
import io.github.opencubicchunks.cubicchunks.api.world.ICubicWorld;
import io.github.opencubicchunks.cubicchunks.core.asm.mixin.ICubicWorldInternal;
import mcp.MethodsReturnNonnullByDefault;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.management.PlayerList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import org.bukkit.Location;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import javax.annotation.ParametersAreNonnullByDefault;

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
@Mixin(PlayerList.class)
public abstract class MixinPlayerList_Bukkit_Sided {

    /*
     * CraftBukkit has a different return value for this method comparing to vanilla.
     * CB: String playerLoggedOut(EntityPlayerMP);
     * Vanilla: void playerLoggedOut(EntityPlayerMP);
     */
    @Redirect(method = "playerLoggedOut(Lnet/minecraft/entity/player/EntityPlayerMP;)Ljava/lang/String;",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/chunk/Chunk;markDirty()V", ordinal = 0),
            require = 1)
    private void setChunkModifiedOnPlayerLoggedOut(Chunk chunkIn, EntityPlayerMP playerIn) {
        ICubicWorldInternal world = (ICubicWorldInternal) playerIn.getServerWorld();
        if (world.isCubicWorld()) {
            world.getCubeFromCubeCoords(playerIn.chunkCoordX, playerIn.chunkCoordY, playerIn.chunkCoordZ).markDirty();
        } else {
            ((World) world).getChunk(playerIn.chunkCoordX, playerIn.chunkCoordZ).markDirty();
        }
    }

    /*
     * CraftBukkit changed the logic of how Vanilla "respawns" a player.
     * In vanilla, the player instance will be recreated and the player's inventory will be copied over,
     * while in CB, player instance is always same while the referenced player is online,
     * and they offer another method "moveToWorld" to handle this.
     */
    @Inject(method = "moveToWorld(Lnet/minecraft/entity/player/EntityPlayerMP;IZLorg/bukkit/Location;Z)Lnet/minecraft/entity/player/EntityPlayerMP;", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/gen/ChunkProviderServer;provideChunk(II)Lnet/minecraft/world/chunk/Chunk;"))
    private void createPlayerChunk(EntityPlayerMP playerIn, int dimension, boolean conqueredEnd,
            Location location, boolean avoidSuffocation, CallbackInfoReturnable<EntityPlayerMP> cir) {
        if (!((ICubicWorld) playerIn.world).isCubicWorld()) {
            return;
        }
        for (int dCubeY = -8; dCubeY <= 8; dCubeY++) {
            ((ICubicWorld) playerIn.world).getCubeFromBlockCoords(playerIn.getPosition().up(Coords.cubeToMinBlock(dCubeY)));
        }
    }

    @ModifyConstant(method = "moveToWorld(Lnet/minecraft/entity/player/EntityPlayerMP;IZLorg/bukkit/Location;Z)Lnet/minecraft/entity/player/EntityPlayerMP;",
            constant = @Constant(doubleValue = 256), remap = false)
    private double getMaxHeight(double _256, EntityPlayerMP playerIn, int dimension, boolean conqueredEnd, Location location, boolean avoidSuffocation) {
        // +/- 8 chunks around the original position are loaded because of an inject above
        if (!playerIn.world.isBlockLoaded(new BlockPos(playerIn))) {
            return Double.NEGATIVE_INFINITY;
        }
        return ((ICubicWorld) playerIn.world).getMaxHeight();
    }
}
